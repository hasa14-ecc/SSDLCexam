<h1>Selamat datang di halaman aman</h1>
<p>Anda telah login dan dapat melihat konten ini.</p>
